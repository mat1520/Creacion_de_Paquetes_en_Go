package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"

	"github.com/fatih/color"
	"github.com/mat1520/Creacion_de_Paquetes_en_Go/contador"
	"github.com/mat1520/Creacion_de_Paquetes_en_Go/conversor"
)

func main() {

	var nombre string
	color.New(color.FgYellow).Print("Ingrese su nombre: ")
	fmt.Scanln(&nombre)
	color.Red("¡Hola, %s! Bienvenido al programa.\n\n", nombre)

	titulo := color.New(color.FgCyan, color.Bold)
	opcion := color.New(color.FgGreen)
	destacado := color.New(color.FgYellow, color.Bold)
	error := color.New(color.FgRed)

	titulo.Println("=== DEMO DE MIS PAQUETES MAT1520 ===")
	fmt.Println()

	scanner := bufio.NewScanner(os.Stdin)

	for {
		fmt.Println("Opciones:")
		opcion.Println("1.  Probar contador de vocales")
		opcion.Println("2.  Probar conversor de divisas")
		opcion.Println("3.  Salir")

		destacado.Print("\nElige una opción (1-3): ")

		scanner.Scan()
		eleccion := strings.TrimSpace(scanner.Text())

		switch eleccion {
		case "1":
			destacado.Println("\n--- PROBANDO CONTADOR DE VOCALES ---")
			contador.ContadorDeVocales()

		case "2":
			destacado.Println("\n--- PROBANDO CONVERSOR DE DIVISAS ---")
			conversor.ConversorDivisas()

		case "3":
			titulo.Println("¡Hasta luego! " + nombre)
			return

		default:
			error.Println("Opción no válida para " + nombre + ". Intenta de nuevo.")
		}
	}
}
